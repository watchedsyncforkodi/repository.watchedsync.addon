#
#
# Copyright 2019-2021 CSS
#
# This software is unpublished work which is proprietary to CSS.
# Any distribution is strictly forbidden
#
#

import sys
import os
import threading
import json
import requests
import xbmc
import xbmcvfs
import xbmcaddon

LIB_RESOURCES_PATH = xbmcvfs.translatePath(os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'lib'))
sys.path.append(LIB_RESOURCES_PATH)

""" Local module imports - need to be after LIB_RESOURCES_PATH """
from watchsync.logging import KodiLog
from watchsync.auth import AuthBoto3Direct, AuthSessionError
from watchsync.utils import BackgroundThread, getSettingAsString, indicate_connection_offline, indicate_connection_online
from watchsync.utils import scan_video_library, update_content_watch_status, setSettingAsBool
from watchsync.utils import find_content_with_filepath, setSettingAsString, getString
from watchsync.utils import get_tvshowid_from_uniqueid, get_movieid_from_uniqueid, issue_kodi_jsonrpc_command
from watchsync.utils import remove_empty_tvshows
from watchsync.credentials import get_device_client_id
# import sentry_sdk
import boto3
from botocore.exceptions import ClientError, ConnectionError, HTTPClientError

__addon__ = xbmcaddon.Addon()
__addonname__ = __addon__.getAddonInfo('name')
__addonversion__ = __addon__.getAddonInfo('version')
__addonid__ = __addon__.getAddonInfo('id')
__addonpath__ = __addon__.getAddonInfo('path')
__addonprofile__ = xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))

# sentry_sdk.init(
#     "https://9872e16f507545fa9edcdcbf47632fe7@o425593.ingest.sentry.io/5510343",
#     environment="production",
#     release="{}@{}".format(__addonid__, __addonversion__)
# )


""" Configuration Variables
"""
REGISTER_TIMEOUT = 20.0
REGISTER_MAX_BACKOFF = 433
HTTP_GET_TIMEOUT = 3.1
""" End of Configuration Variables
"""


class VideoLibraryUpdateThread(BackgroundThread):

    def __init__(self, runtime_config, runtime_config_lock, wakeup_flag):
        super(VideoLibraryUpdateThread, self).__init__(name="VideoLibraryUpdateThread")

        self.rt_config = runtime_config
        self.rt_lock = runtime_config_lock
        self.wakeup_flag = wakeup_flag
        self.log = KodiLog(__file__, __name__)

        with self.rt_lock:
            self.auth_session = runtime_config['session_auth']
            self.update_poll_interval = runtime_config['update_library_poll_interval']
            self.update_queue_url = runtime_config['update_library_queue_url']
            # Setup ignore update list
            runtime_config['ignore_updates_from'] = {
                'movie': set(),
                'episode': set(),
                'tvshow': set(),  # not used
                'musicvideo': set(),  # not used
                'season': set(),  # not used
            }
            # Setup scan list
            runtime_config['scan_history'] = set()

        self.boto3_auth_session = AuthBoto3Direct(self.auth_session,
                                                  assume_role_arn='arn:aws:iam::251217536828:role/watchsync_kodi_client_role',
                                                  role_session_name=get_device_client_id()[:64],
                                                  session_duration=60*60*6)  # 6 hours

        # Get the boto3 service resource.
        self.boto3_session = boto3.session.Session(region_name='eu-west-1')
        self.this_device = get_device_client_id()

    def is_kodi_busy(self):
        """
            Determines if the local kodi device is considered busy to do library operations

        :return True/False:
        """
        is_playing = xbmc.Player().isPlaying()
        is_player_paused = xbmc.getCondVisibility('Player.Paused')
        is_scanning_library = xbmc.getCondVisibility('Library.IsScanning')

        if (is_playing and not is_player_paused) or is_scanning_library:
            return True

        return False

    def get_next_msg(self):
        """
            Get next message from the queue

        :return None/msg dict:
        """
        try:
            sqs = self.boto3_session.resource('sqs', **self.boto3_auth_session.get_resource_access_arguments())
            sqs_queue = sqs.Queue(self.update_queue_url)
            next_msg = sqs_queue.receive_messages(MaxNumberOfMessages=1,
                                                  MessageAttributeNames=['*'])
            indicate_connection_online()

        except AuthSessionError as e:
            self.log.warning("Temporary authentication error: {}".format(e))
            indicate_connection_offline()
            next_msg = []

        except requests.RequestException as e:
            self.log.warning("Temporary communications error: {}".format(e))
            indicate_connection_offline()
            next_msg = []

        except (ClientError, ConnectionError, HTTPClientError) as e:
            self.log.warning("Temporary communications error: {}".format(e))
            indicate_connection_offline()
            next_msg = []

        except SystemExit as e:
            indicate_connection_offline()
            next_msg = []

        except Exception as e:
            indicate_connection_offline()
            next_msg = []
            # sentry_sdk.capture_exception()
            self.log.error("Unexpected error - please raise issue on "
                           "https://github.com/watchedsyncforkodi/service.watchedsync/issues")
            self.log.error(e)

        return next_msg

    def mark_msg_complete(self, msg):
        """
            Mark msg has completed processing

        :param msg:
        :return:
        """
        try:
            # Can delete the message from the SQS queue once complete
            msg.delete()
        except:
            self.log.warning("Unable to set incoming message as complete. This will block new messages if this warning appears multiple times")
            raise
            # sentry_sdk.capture_exception()

    def scan_library_once_with_dirpath(self, scan_dirpath):
        """
            Scan library once with supplied directory path

        :param scan_dirpath:
        :return True if scan initiated otherwise false:
        """
        with self.rt_lock:
            if scan_dirpath not in self.rt_config['scan_history']:
                self.log.debug("Initiate library scan with directory path: {}".format(scan_dirpath))
                # Haven't instructed to scan previously so scan now
                scan_video_library(scan_dirpath)
                # Update scan history
                self.rt_config['scan_history'].add(scan_dirpath)
                return True
            else:
                # Scanned previously - don't try again
                self.rt_config['scan_history'].remove(scan_dirpath)
                return False

    def update_content_watch_status_in_library(self, update_type, content_id, content_details):
        """
            Update content watch status

        :return:
        """
        with self.rt_lock:
            # runtime_config['ignore_updates_from'] = {
            #     'movie': set(),
            #     'episode': set()
            # }
            self.rt_config['ignore_updates_from'][update_type].add(content_id)
        return update_content_watch_status(update_type, content_id, content_details)

    def stop(self):
        # call from parent to stop and exit thread
        self.exit_flag.set()
        # Trigger wake up
        self.wakeup_flag.set()

    def run(self):
        # Called by calling start()
        self.log.info("Starting thread: {}".format(threading.current_thread().name))

        # Set setting for connected online to false. Will set real status later in get_next_msg
        setSettingAsBool("connected_online", False)

        # Continuously loop until exit
        while not self.exit_flag.wait(1):

            try:
                self.log.debug("Remote thread going to sleep for {}s".format(self.update_poll_interval))
                # Wait until poll interval time or received a wakeup command
                wakeup_cmd = self.wakeup_flag.wait(self.update_poll_interval)
                # Reset wakeup flag
                self.wakeup_flag.clear()
                self.log.debug("Remote thread awoken. Wakeup command status: {}".format(wakeup_cmd))

                # Continue polling for new messages until no new messages
                msgs_to_process = True
                while msgs_to_process:
                    # Reset
                    msgs_to_process = []

                    # Check we haven't been asked to exit then wait a brief moment to try to make sure kodi is not busy
                    # following any wake command being received above
                    if not self.exit_flag.wait(1.5):
                        # Check kodi is not busy before continuing
                        if not self.is_kodi_busy():

                            # Try to get message from AWS. Returns empty if no messages found
                            msgs_to_process = self.get_next_msg()

                            # Will return list even if single message is returned
                            for msg_to_process in msgs_to_process:

                                # Check we haven't been asked to exit then process message after short pause
                                if not self.exit_flag.wait(0.85):
                                    # Check kodi is not busy
                                    if not self.is_kodi_busy():

                                        try:
                                            msg_body = json.loads(msg_to_process.body)
                                        except:
                                            msg_body = msg_to_process.body

                                        # Build msg attrs into Python dict
                                        msg_attrs = {}
                                        if msg_to_process.message_attributes:
                                            for k in msg_to_process.message_attributes:
                                                # Build msg_attrs
                                                msg_attrs[k] = msg_to_process.message_attributes[k].get('StringValue', None)

                                        # Ignore locally sourced messages
                                        if msg_attrs['origin'] == self.this_device:
                                            # Received unexpected message
                                            self.log.warning("Received unexpected message with origin from this device")
                                            self.mark_msg_complete(msg_to_process)
                                            continue

                                        # Handle updating poll interval
                                        if msg_attrs['event'] == 'kodi.update_poll_interval.changed':
                                            if 'new_poll_interval' in msg_body:
                                                # Cap to minimum of 10 seconds
                                                new_interval = int(msg_body['new_poll_interval'])
                                                self.update_poll_interval = max(10, new_interval)
                                                self.log.debug("Updated poll interval to {}".format(self.update_poll_interval))

                                        # Handle Kodi JSON RPC request
                                        elif msg_attrs['event'] == 'kodi.json_rpc.run':
                                            if 'payload' in msg_body:
                                                # Run command
                                                result = issue_kodi_jsonrpc_command(msg_body['payload'])

                                                # TODO: Do we need the result back?

                                        # Handle removing empty TV shows request
                                        elif msg_attrs['event'] == 'kodi.remove.empty_tvshows':

                                            # Could be long process - mark message delete first
                                            self.mark_msg_complete(msg_to_process)
                                            remove_empty_tvshows()
                                            # As message already deleted - finish here
                                            continue

                                        # Handle removing video library content
                                        elif msg_attrs['event'] == 'kodi.remove.video_library_content':

                                            if 'payload' not in msg_body:
                                                # Received unexpected message
                                                self.log.warning(
                                                    "Received unexpected kodi.remove.video_library_content payload: {}".format(
                                                        msg_body))
                                                self.mark_msg_complete(msg_to_process)
                                                continue

                                            programme_type = msg_body['payload']['programme_type']
                                            operations = {
                                                "episode": {
                                                    "id_name": "episodeid",
                                                    "remove_method": "VideoLibrary.RemoveEpisode"
                                                },
                                                "movie": {
                                                    "id_name": "movieid",
                                                    "remove_method": "VideoLibrary.RemoveMovie"
                                                }
                                            }
                                            if programme_type not in operations:
                                                # Received unexpected message
                                                self.log.warning("Received unexpected kodi.remove.video_library_content programme type: {}".format(programme_type))
                                                self.mark_msg_complete(msg_to_process)
                                                continue

                                            this_op = operations[programme_type]

                                            self.log.info("Received remove {} video library content request".format(programme_type))
                                            self.log.debug("Payload received is: {}".format(msg_body['payload']))
                                            search_filename = msg_body['payload']['filename']
                                            search_dirpath = msg_body['payload']['dirpath']
                                            found_exact_match = False

                                            for c in find_content_with_filepath(programme_type, search_filename, search_dirpath):

                                                log_s = "Found {} matching full path to remove: {}"
                                                self.log.debug(log_s.format(programme_type, c))
                                                found_exact_match = True

                                                payload = {
                                                    "method": this_op["remove_method"],
                                                    "params": {
                                                        this_op["id_name"]: c[this_op["id_name"]]
                                                    }
                                                }

                                                # Run command
                                                result = issue_kodi_jsonrpc_command(payload)
                                                self.log.info("Result {} for removing video library content {} (#{}) - {}"
                                                              .format(result, programme_type, c[this_op["id_name"]], c['label']))

                                            if not found_exact_match:
                                                self.log.info("No match found on this device. Remove video library content request ignored")

                                        # Handle VideoLibrary OnUpdate
                                        elif msg_attrs['event'].endswith("VideoLibrary.OnUpdate"):

                                            update_type = msg_body['notification']['data']['item']['type']
                                            operations = {
                                                "episode": {
                                                    "id": "episodeid",
                                                    "typedetails": "episodedetails"
                                                },
                                                "movie": {
                                                    "id": "movieid",
                                                    "typedetails": "moviedetails"
                                                }
                                            }
                                            if update_type not in operations:
                                                # Received unexpected message
                                                self.log.warning("Received unexpected VideoLibrary.OnUpdate type: {}".format(update_type))
                                                self.mark_msg_complete(msg_to_process)
                                                continue

                                            this_op = operations[update_type]

                                            self.log.debug("Detected {} video update request".format(update_type))
                                            search_filename = msg_body[this_op['typedetails']]['filename']
                                            search_dirpath = msg_body[this_op['typedetails']]['dirpath']
                                            found_exact_match = False
                                            for c in find_content_with_filepath(update_type, search_filename, search_dirpath):
                                                log_s = "Standard method - found {} matching full path to update: {}"
                                                self.log.debug(log_s.format(update_type, c))
                                                found_exact_match = True
                                                self.update_content_watch_status_in_library(update_type,
                                                                                            c[this_op["id"]],
                                                                                            msg_body[this_op['typedetails']])
                                                self.log.info("Successfully sync watch status for {} - {}".format(update_type,
                                                                                                                  c['label']))

                                            if update_type == 'episode':

                                                if not found_exact_match:
                                                    # Find TV show on this device
                                                    this_tvshowid = get_tvshowid_from_uniqueid(msg_body['tvshowdetails']['uniqueid'])
                                                    found_different_path_match = False

                                                    if this_tvshowid:

                                                        for c in find_content_with_filepath(update_type, search_filename):
                                                            if c['tvshowid'] == this_tvshowid:
                                                                # Found match tv show episode based on filename and tvshowid
                                                                log_s = "Fallback method - found {} matching filename and tvshowid {}"
                                                                self.log.debug(log_s.format(update_type, this_tvshowid))
                                                                found_different_path_match = True
                                                                self.update_content_watch_status_in_library(update_type,
                                                                                                            c[this_op["id"]],
                                                                                                            msg_body[this_op['typedetails']])
                                                                self.log.info(
                                                                    "Successfully sync watch status for {} - {}".format(update_type,
                                                                                                                        c['label']))

                                                    if not found_different_path_match:
                                                        # Can't find matching tv show or filename
                                                        # As last ditch attempt, try to scan the library
                                                        if self.scan_library_once_with_dirpath(search_dirpath):
                                                            # Skip more processing and wait until message is repeated
                                                            continue
                                                        else:
                                                            # Tried scan and still got here - failed
                                                            content_title = "{} - {}".format(msg_body['tvshowdetails']['title'],
                                                                                             msg_body['episodedetails'].get('label', '(Unknown Title)'))
                                                            self.log.warning("Wasn't able to sync {} '{}'. Couldn't find a "
                                                                             "local match".format(update_type, content_title))

                                            elif update_type == 'movie':

                                                if not found_exact_match:
                                                    # Find film on this device
                                                    this_movieid = get_movieid_from_uniqueid(msg_body['moviedetails']['uniqueid'])
                                                    found_different_path_match = False

                                                    if this_movieid:

                                                        for c in find_content_with_filepath(update_type, search_filename):
                                                            if c['movieid'] == this_movieid:
                                                                # Found match film based on filename and movieid
                                                                log_s = "Fallback method - found {} matching filename and movieid {}"
                                                                self.log.debug(log_s.format(update_type, this_movieid))
                                                                found_different_path_match = True
                                                                self.update_content_watch_status_in_library(update_type,
                                                                                                            c[this_op["id"]],
                                                                                                            msg_body[this_op['typedetails']])
                                                                self.log.info(
                                                                    "Successfully sync watch status for {} - {}".format(update_type,
                                                                                                                        c['label']))

                                                    if not found_different_path_match:
                                                        # Can't find matching film.
                                                        # As last ditch attempt, try to scan the library
                                                        if self.scan_library_once_with_dirpath(search_dirpath):
                                                            # Skip more processing and wait until message is repeated
                                                            continue
                                                        else:
                                                            # Tried scan and still got here - failed
                                                            content_title = "{}".format(msg_body['moviedetails']['title'])
                                                            self.log.warning("Wasn't able to sync {} '{}'. Couldn't find a "
                                                                             "local match".format(update_type, content_title))

                                        # Finished processing msg
                                        self.mark_msg_complete(msg_to_process)

            except Exception as e:
                # sentry_sdk.capture_exception()
                self.log.error("Unexpected error - please raise issue on "
                               "https://github.com/watchedsyncforkodi/service.watchedsync/issues")
                self.log.error(e)
                raise

        # Update settings to mark offline
        setSettingAsString("addon_status", getString(32011))
        setSettingAsBool("connected_online", False)
        self.log.info("Exiting thread: {}".format(threading.current_thread().name))
