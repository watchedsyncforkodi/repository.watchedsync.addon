#
#
# Copyright 2019-2021 CSS
#
# This software is unpublished work which is proprietary to CSS.
# Any distribution is strictly forbidden
#
#

import sys
import os
import requests
import uuid
import hmac
import hashlib
import xbmc
import xbmcvfs
import xbmcaddon

LIB_RESOURCES_PATH = xbmcvfs.translatePath(os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'lib'))
sys.path.append(LIB_RESOURCES_PATH)

""" Local module imports - need to be after LIB_RESOURCES_PATH """
from watchsync.logging import KodiLog
from watchsync.auth import AuthSessionServerError, AuthSessionClientError
from watchsync.credentials import is_device_registered, register_device, authorise_device, migrate_credentials_from_settings
from watchsync.utils import getString, setSettingAsString

__addon__ = xbmcaddon.Addon()
__addonname__ = __addon__.getAddonInfo('name')
__addonversion__ = __addon__.getAddonInfo('version')
__addonid__ = __addon__.getAddonInfo('id')
__addonpath__ = __addon__.getAddonInfo('path')
__addonprofile__ = xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))

log = KodiLog(__file__, __name__)

""" Configuration Variables
"""
_request_timeout = 15
""" End of Configuration Variables
"""


def get_kodi_info_label(label):
    """
        Return kodi info label, handling temporary Busy errors

    :param label:
    :return string with info label:
    """
    # Keep looping until "Busy" is not returned anymore
    busy_signal = xbmc.getLocalizedString(503)
    res = busy_signal
    while res == busy_signal:
        res = xbmc.getInfoLabel(label)
        xbmc.sleep(250)
    return res


def get_session_endpoints(runtime_config, runtime_config_lock):
    """
        Return the endpoints for these sessions

    :param runtime_config:
    :param runtime_config_lock:
    :return dict of endpoints:
    """
    # Simulate external call
    xbmc.sleep(750)
    # TODO: Replace stub endpoints
    stub_endpoints = {
        'register_endpoint': u'https://keq4fgzes4.execute-api.eu-west-1.amazonaws.com/conceptv1/api/register_device',
        'runtime_config_endpoint': u'https://keq4fgzes4.execute-api.eu-west-1.amazonaws.com/conceptv1/api/get_device_config'
    }
    with runtime_config_lock:
        runtime_config['endpoints'] = stub_endpoints

    return stub_endpoints


def retrieve_system_info(runtime_config, runtime_config_lock):
    """
        Retrieve kodi system information

    :param runtime_config:
    :param runtime_config_lock:
    :return dict with system info:
    """
    sk = b'\xd5\xb3\x9c+\xf9=\xd0\n\xdb\xa4\x8b\xe3\xea\x88\xdf=\xbb\x96\xb4\xb8\xe5)4Wr\xf1@\xcc\xbfZ\xaf\xb3.?\x10!\x80lD\xc2\xb6UM\xd0\xb0\xc3\xb1@\xf6K\xc35\xf3+\x83MO\x89d\xe9\x1f0k\xbd\xe2o\xbc\xdci\x0c\xcaV\x1d\x81(.\x7f\x93\x1a8\x0b\x1f\xe5\xce\xc3GP\xeeU]\t\xb8\x1a\x12\xb7\xd9.\xde"\x99b\xc4;O+:\xf6\xb8\xba+\xf6pVel$\xbe\xd0j\x0e\xf8"\xae\x02q\x1b\xc4\xd8'
    mac_hash = hmac.new(sk, get_kodi_info_label("Network.MacAddress").lower().encode('utf-8'), digestmod=hashlib.sha256).hexdigest()
    system_info = {
        "System.OSVersionInfo": get_kodi_info_label("System.OSVersionInfo"),
        "System.BuildVersion": get_kodi_info_label("System.BuildVersion"),
        "System.Uptime": get_kodi_info_label("System.Uptime"),
        "System.FriendlyName": get_kodi_info_label("System.FriendlyName"),
        "Network.IPAddress": get_kodi_info_label("Network.IPAddress"),
        "Network.MacAddress.Hash": mac_hash,
        "UserAgent": xbmc.getUserAgent(),
        "Language": xbmc.getLanguage()
    }

    # Determine system platform
    if xbmc.getCondVisibility("System.Platform.UWP"):
        system_info["System.Platform"] = u"UWP"
    elif xbmc.getCondVisibility("System.Platform.IOS"):
        system_info["System.Platform"] = u"IOS"
    elif xbmc.getCondVisibility("System.Platform.Darwin"):
        system_info["System.Platform"] = u"Darwin"
    elif xbmc.getCondVisibility("System.Platform.Android"):
        system_info["System.Platform"] = u"Android"
    elif xbmc.getCondVisibility("System.Platform.OSX"):
        system_info["System.Platform"] = u"OSX"
    elif xbmc.getCondVisibility("System.Platform.Windows"):
        system_info["System.Platform"] = u"Windows"
    elif xbmc.getCondVisibility("System.Platform.Linux"):
        system_info["System.Platform"] = u"Linux"

    with runtime_config_lock:
        runtime_config['system_info'] = system_info
        log.debug("Retrieved system information")

    return system_info


def get_runtime_config(runtime_config, runtime_config_lock):
    """
        Get runtime config from service

    :param runtime_config:
    :param runtime_config_lock:
    :return:
    """
    config_endpoint = None
    auth_session = None
    with runtime_config_lock:
        # Use existing session auth
        auth_session = runtime_config['session_auth']
        config_endpoint = runtime_config['endpoints']['runtime_config_endpoint']

    custom_headers = {
        'User-Agent': xbmc.getUserAgent(),
        'Content-Type': 'application/json',
        'Authorization': auth_session.get_authorization_header()
    }

    r = requests.get(url=config_endpoint,
                     headers=custom_headers,
                     timeout=_request_timeout)
    r.raise_for_status()
    result = r.json()
    with runtime_config_lock:
        # Get runtime config from service. Set minimum of 10 seconds for poll interval
        runtime_config['update_library_poll_interval'] = max(10, result['queue_poll_interval'])
        runtime_config['update_library_queue_url'] = result['queue_endpoint']
        # if 'capabilities' in result:
        #     runtime_config['capabilities'] = result['capabilities']
        #


def perform_setup_function(runtime_config, runtime_config_lock):
    """
        Perform all the setup functions

    :param runtime_config:
    :param runtime_config_lock:
    :return True/False - Whether setup functions have completed successfully:
    """
    kodi_system = xbmc.Monitor()
    setup_result = False
    setup_complete = False
    setup_attempts = 0

    # Indicate to user we are starting up
    # 32007 - Starting up...
    setSettingAsString("addon_status", getString(32007))

    while not kodi_system.abortRequested() and not setup_complete:
        try:
            setup_attempts += 1

            # Stub setup - loop 2 times before returning
            kodi_system.waitForAbort(4)
            if not kodi_system.abortRequested() and setup_attempts >= 2:

                retrieve_system_info(runtime_config, runtime_config_lock)
                get_session_endpoints(runtime_config, runtime_config_lock)
                migrate_credentials_from_settings()

                if not is_device_registered():
                    # Need to register device...
                    try:
                        # Attempt to register device
                        register_device(runtime_config, runtime_config_lock)

                    except requests.exceptions.RequestException as err:
                        # Failure during registration - assume permanent
                        log.error("Failed while registering device: {}".format(err))
                        break

                    # Pause before trying to authorise device if we have just registered
                    # to allow backend systems to update
                    kodi_system.waitForAbort(2.5)

                if not kodi_system.abortRequested():
                    log.info("Snapshot 3")
                    authorise_device(runtime_config, runtime_config_lock)
                    log.info("Snapshot 4")
                    try:
                        get_runtime_config(runtime_config, runtime_config_lock)
                        log.info("Snapshot 5")
                    except requests.exceptions.RequestException as err:
                        # Failure during retrieving config - assume permanent
                        log.error("Failed while getting runtime config: {}".format(err))
                        break

                    # Mark setup successful
                    setup_complete = True
                    setup_result = True

                    # Indicate to user we have completed setup
                    # 32009 - Registered
                    setSettingAsString("addon_status", getString(32009))

        except AuthSessionClientError as err:
            # If client based assume this is a permanent error that needs human input
            log.error("Failed client authentication during setup: {}".format(err))
            break

        except AuthSessionServerError as err:
            # If server based assume then assume this is a temporary error and try again later
            log.warning("Failed server authentication during setup: {}".format(err))
            # Go round the while loop again

    with runtime_config_lock:
        runtime_config['setup_complete'] = setup_complete
        log.debug("Performed setup function")

    return setup_result
