#
#
# Copyright 2019-2022 CSS
#
# This software is unpublished work which is proprietary to CSS.
# Any distribution is strictly forbidden
#
#

import sys
import os
import threading
import json
from collections import deque

import requests
import tempfile
import hashlib
import pytz
from datetime import datetime
from time import monotonic
from functools import lru_cache
import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon

LIB_RESOURCES_PATH = xbmcvfs.translatePath(os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'lib'))
sys.path.append(LIB_RESOURCES_PATH)

""" Local module imports - need to be after LIB_RESOURCES_PATH """
from watchsync.logging import KodiLog
from watchsync.event_logger import EventLogger
from watchsync.auth import AuthBoto3Direct, AuthSessionError
from watchsync.utils import BackgroundThread, getSettingAsString, indicate_connection_offline, \
    indicate_connection_online, get_movie_details, get_episode_details
from watchsync.utils import scan_video_library, update_content_watch_status, setSettingAsBool
from watchsync.utils import find_content_with_filepath, setSettingAsString, getString
from watchsync.utils import get_tvshowid_from_uniqueid, get_movieid_from_uniqueid, issue_kodi_jsonrpc_command
from watchsync.utils import get_results_from_kodi_jsonrpc, get_tvshow_details, getSettingAsBool
# import sentry_sdk
import boto3
from botocore.exceptions import ClientError, ConnectionError, HTTPClientError

__addon__ = xbmcaddon.Addon()
__addonname__ = __addon__.getAddonInfo('name')
__addonversion__ = __addon__.getAddonInfo('version')
__addonid__ = __addon__.getAddonInfo('id')
__addonpath__ = __addon__.getAddonInfo('path')
__addonprofile__ = xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__backupchecksum__ = xbmcvfs.validatePath(os.path.join(__addonprofile__, 'backup_checksum.json'))

# sentry_sdk.init(
#     "https://9872e16f507545fa9edcdcbf47632fe7@o425593.ingest.sentry.io/5510343",
#     environment="production",
#     release="{}@{}".format(__addonid__, __addonversion__)
# )


""" Configuration Variables
"""
REGISTER_TIMEOUT = 20.0
REGISTER_MAX_BACKOFF = 433
HTTP_GET_TIMEOUT = 3.1
""" End of Configuration Variables
"""


def get_all_watched_status():
    """
        Return iterator of all watch statuses for both TV shows and fillms

    :return: Iterator of watch status
    """
    log = KodiLog(__file__, __name__)

    # content type logic
    content_types = [
        {
            "method": "VideoLibrary.GetEpisodes",
            "result_name": "episodes",
            # "properties": ["tvshowid", "title", "file", "lastplayed", "resume", "playcount", "season", "episode"],
            "properties": ["tvshowid", "resume", "playcount", "lastplayed"],
        },
        {
            "method": "VideoLibrary.GetMovies",
            "result_name": "movies",
            # "properties": ["title", "file", "lastplayed", "resume", "playcount", "uniqueid"],
            "properties": ["resume", "playcount", "lastplayed"],
        }
    ]

    @lru_cache(maxsize=1024)
    def _get_cached_tvshow_details(tvshowid):
        return get_tvshow_details(tvshowid)

    count_total = 0
    count_skipped = 0
    count_movie = 0
    count_episode = 0
    for c in content_types:
        for r in get_results_from_kodi_jsonrpc(c['method'], c['result_name'], c['properties']):

            count_total += 1

            # Backup only if played before or watched/resume points exist
            if r["playcount"] == 0 and r["resume"]["position"] == 0.0 and r["lastplayed"] == '':
                # No activity detected on this result - ignore
                count_skipped += 1
                continue

            output = {}
            if c['method'] == "VideoLibrary.GetMovies":
                output['moviedetails'] = get_movie_details(r['movieid'])
                count_movie += 1
            elif c['method'] == "VideoLibrary.GetEpisodes":
                output['episodedetails'] = get_episode_details(r['episodeid'])
                output['tvshowdetails'] = _get_cached_tvshow_details(r["tvshowid"])
                count_episode += 1

            # # Merge data from tvshow details if episodes
            # if c['result_name'] == "episodes":
            #     r.update(_get_cached_tvshow_details(r["tvshowid"]))

            yield output

    log.debug(f"Watched Status Metrics: total_count={count_total}, skipped_count={count_skipped}, "
              f"movie_count={count_movie}, episode_count={count_episode}")


def backup_watchedstatus(runtime_config: dict, runtime_config_lock: threading.Lock,
                         exit_flag: threading.Event, el: EventLogger, force_backup=False):
    """
        Backup all resume points and watched status from kodi device

    :param runtime_config: Runtime configuration
    :param runtime_config_lock: Runtime config access lock
    :param exit_flag: Flag to indicate exit (due to shutdown)
    :param el: Event Logger
    :param force_backup: force backup even if no changes
    :return: status message of busy, error, or completed_ok
    """
    log = KodiLog(__file__, __name__)
    backup_hash = hashlib.sha3_256()
    completed_data = {
        "metrics": {},
        "checksum_matches": False,
        "resumepoint_count": 0,
        "last_checksum_data": None,
        "checksum_sha3_256": None,
        "force_backup": force_backup,
        'application': {
            'app_id': __addonid__,
            'app_name': __addonname__,
            'app_version': __addonversion__
        }
    }

    # Shortcuts
    rt_config = runtime_config
    rt_lock = runtime_config_lock
    config = {
        'enabled': False
    }

    log.info("Starting backup of watched status")

    # Get runtime config if available
    with rt_lock:
        try:
            config = runtime_config['capabilities']['backup'].copy()

        except KeyError:
            log.warning("Did not receive the expected configuration")

    if not config['enabled']:
        log.warning("Backup functionality is not enabled. Please contact support.")
        return "error"

    # Check whether already running
    window = xbmcgui.Window(10000)
    if window.getProperty(__addonid__ + ".backup.running") == 'true':
        log.warning("Can't run backup process as it is already running")
        return "busy"

    # Set "lock" property that we are running
    window.setProperty(__addonid__ + ".backup.running", "true")

    log.debug("Acquired exclusive lock to run backup")

    with tempfile.NamedTemporaryFile('wt+', encoding="utf-8", newline='\n') as temp_backup_file:

        # Phase 1 - retrieve watch status
        start = monotonic()
        for count, r in enumerate(get_all_watched_status()):
            r_converted = json.dumps(r, sort_keys=True)
            log.debug("Resume point details: {}".format(r_converted))
            temp_backup_file.write(r_converted)
            temp_backup_file.write('\n')
            backup_hash.update(r_converted.encode('utf-8'))

            # Quit if exit flag being triggered
            if exit_flag.is_set():
                # Release "lock" property
                window.setProperty(__addonid__ + ".backup.running", "false")
                return "error"

        elapsed = monotonic() - start
        completed_data['resumepoint_count'] = count + 1
        completed_data['checksum_sha3_256'] = backup_hash.hexdigest()
        completed_data['metrics']['phase_1'] = "{:.1f}".format(elapsed * 1000)
        log.debug("Phase 1 - retrieved watch status (took {:.1f}ms)".format(elapsed * 1000))

        # Check whether checksum matches
        last_checksum = {
            "checksum_sha3_256": "",
            "from_checksum_file": False
        }
        try:
            # On first use there will be no file so expect FileNotFoundError exception
            with open(__backupchecksum__, 'rt', encoding="utf-8", newline='\n') as checksum_file:
                last_checksum = json.load(checksum_file)

        except FileNotFoundError:
            # On first use there will be no file so expect FileNotFoundError exception
            pass

        completed_data['last_checksum_data'] = last_checksum

        if not force_backup and (backup_hash.hexdigest() == last_checksum['checksum_sha3_256']):
            # No changes since last backup
            log.debug("Last checksum data: {}".format(last_checksum))
            log.debug("This backup checksum: {}".format(backup_hash.hexdigest()))
            completed_data['checksum_matches'] = True
            el.new('kodi.client.backup.complete', completed_data)
            # Release "lock" property
            window.setProperty(__addonid__ + ".backup.running", "false")
            log.info("Completed backup of watched status successfully. No changes detected since last backup")
            return "completed_ok"

        # Phase 2 - changes detected - need to upload to cloud

        # Check minimum interval
        if not force_backup and ('last_updated_utc_datetime' in last_checksum):
            lt = datetime.fromisoformat(last_checksum['last_updated_utc_datetime'])
            dt = datetime.now(pytz.utc) - lt
            wait_until_mins = (config['minimum_refresh_time'] - dt.total_seconds()) / 60.0
            log.debug("It has been {} seconds since last backup upload".format(dt.total_seconds()))

            if dt.total_seconds() < config['minimum_refresh_time']:
                log.info(f"Backup deferred as recently completed. Will automatically try again after {int(wait_until_mins)} minutes.")
                # Release "lock" property
                window.setProperty(__addonid__ + ".backup.running", "false")
                return "error"

        # Reset file position
        temp_backup_file.seek(0)
        completed_data['checksum_matches'] = False
        start = monotonic()
        block_upload = deque()
        for line in temp_backup_file:
            block_upload.append(json.loads(line))

            if len(block_upload) >= 250:
                # Send to cloud in blocks of 250
                el.new('kodi.client.backup.resumepoints', list(block_upload))
                log.debug("Block of {} resume points to be uploaded".format(len(block_upload)))
                block_upload.clear()

        # Send to cloud remaining items in the block upload if needed
        if len(block_upload) > 0:
            el.new('kodi.client.backup.resumepoints', list(block_upload))
            log.debug("Remaining {} resume points to be uploaded".format(len(block_upload)))
            block_upload.clear()

        # Wait for a short while then monitor backlog to see when all resume points have been uploaded
        xbmc.sleep(500)
        while not exit_flag.is_set() and el.backlog_size() > 1:
            xbmc.sleep(1000)

        # Quit if while finished due to exit flag being triggered
        if exit_flag.is_set():
            # Release "lock" property
            window.setProperty(__addonid__ + ".backup.running", "false")
            return "error"

        elapsed = monotonic() - start
        completed_data['metrics']['phase_2'] = "{:.1f}".format(elapsed * 1000)
        log.debug("Phase 2 - upload watch status (took {:.1f}ms)".format(elapsed * 1000))

        # Save checksum details
        this_checksum = {
            "checksum_sha3_256": backup_hash.hexdigest(),
            "from_checksum_file": True,
            "last_updated_utc_datetime": datetime.now(pytz.utc).isoformat(timespec='seconds')
        }
        with open(__backupchecksum__, 'wt', encoding="utf-8", newline='\n') as checksum_file:
            json.dump(this_checksum, checksum_file, sort_keys=True)
            log.debug("Written new backup checksum data: {}".format(this_checksum))

        # TODO: Update settings status

        el.new('kodi.client.backup.complete', completed_data)
        # Release "lock" property
        window.setProperty(__addonid__ + ".backup.running", "false")
        log.info("Completed backup of watched status successfully")
        return "completed_ok"


def automatic_backup_watchedstatus(runtime_config: dict, runtime_config_lock: threading.Lock,
                                   exit_flag: threading.Event, el: EventLogger):
    """
        Check whether automatic backup is enabled and then backup all resume points and watched status from kodi device

    :param runtime_config: Runtime configuration
    :param runtime_config_lock: Runtime config access lock
    :param exit_flag: Flag to indicate exit (due to shutdown)
    :param el: Event Logger
    :return: status message of busy, error, or completed_ok
    """
    log = KodiLog(__file__, __name__)
    # Wait 5 seconds for initial setup to complete
    exit_flag.wait(5.0)
    if not exit_flag.is_set():
        log.debug("Entering automatic_backup_watchedstatus with enabled setting set to: {}".format(getSettingAsBool('automatic_backup_enabled')))
        if getSettingAsBool('automatic_backup_enabled'):
            try:
                return backup_watchedstatus(runtime_config, runtime_config_lock, exit_flag, el)
            except Exception as err:
                log.error("There was an issue while trying to backup watched status. Error was: {}".format(err))
                # TODO: Add try/except to capture exceptions but not crash the repeating thread
                raise

    return None
