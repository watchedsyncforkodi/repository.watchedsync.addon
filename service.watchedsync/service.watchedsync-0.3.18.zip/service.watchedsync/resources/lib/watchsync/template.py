#
#
# Copyright 2016-2021 CSS
#
# This software is unpublished work which is proprietary to CSS.
# Any distribution is strictly forbidden
#

import sys
import os
import threading
import queue
import xbmc
import xbmcvfs
import xbmcaddon

LIB_RESOURCES_PATH = xbmcvfs.translatePath(os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'lib'))
sys.path.append(LIB_RESOURCES_PATH)

""" Local module imports - need to be after LIB_RESOURCES_PATH """
from watchsync.logging import KodiLog
from watchsync.notifications import KodiNotifications


__addon__ = xbmcaddon.Addon()
__addonname__ = __addon__.getAddonInfo('name')
__addonversion__ = __addon__.getAddonInfo('version')
__addonid__ = __addon__.getAddonInfo('id')
__addonpath__ = __addon__.getAddonInfo('path')
__addonprofile__ = xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))


""" Configuration Variables
"""
REGISTER_TIMEOUT = 20.0
REGISTER_MAX_BACKOFF = 433
HTTP_GET_TIMEOUT = 3.1
""" End of Configuration Variables
"""
