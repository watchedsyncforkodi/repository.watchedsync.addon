#
#
# Copyright 2016-2021 CSS
#
# This software is unpublished work which is proprietary to CSS.
# Any distribution is strictly forbidden
#

import sys
import os
import threading
import queue
import xbmc
import xbmcvfs
import xbmcaddon
import xbmcgui

LIB_RESOURCES_PATH = xbmcvfs.translatePath(os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'lib'))
sys.path.append(LIB_RESOURCES_PATH)

""" Local module imports - need to be after LIB_RESOURCES_PATH """
from watchsync.logging import KodiLog
from watchsync.notifications import KodiNotifications, ProcessNotificationsThread
from watchsync.setup import perform_setup_function
from watchsync.remote import VideoLibraryUpdateThread
from watchsync.event_logger import EventLogger
from watchsync.utils import getString, setSettingAsString, setSettingAsBool, displayOKDialog, RepeatingTimerThread
from watchsync.backuprestore import automatic_backup_watchedstatus

# import sentry_sdk


__addon__ = xbmcaddon.Addon()
__addonname__ = __addon__.getAddonInfo('name')
__addonversion__ = __addon__.getAddonInfo('version')
__addonid__ = __addon__.getAddonInfo('id')
__addonpath__ = __addon__.getAddonInfo('path')
__addonprofile__ = xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))

# sentry_sdk.init(
#     "https://9872e16f507545fa9edcdcbf47632fe7@o425593.ingest.sentry.io/5510343",
#     environment="production",
#     release="{}@{}".format(__addonid__, __addonversion__)
# )
# sentry_sdk.set_tag("lang", xbmc.getLanguage())

""" Configuration Variables
"""

""" End of Configuration Variables
"""

log = KodiLog(__file__, __name__)

log.debug('RESOURCES_PATHs: {}'.format(LIB_RESOURCES_PATH))
log.debug('__file__: {}'.format(__file__))


def main():
    """Main function"""
    log.info('Starting')

    # Setup main runtime configuration variables (threadsafe)
    runtime_config = {
        'setup_complete': False
    }
    runtime_config_lock = threading.Lock()
    notification_queue = queue.PriorityQueue()
    exit_flag = threading.Event()
    wakeup_flag = threading.Event()

    kn = KodiNotifications(notification_queue)
    el = None
    worker_threads = []

    try:
        # Reset backup running property
        window = xbmcgui.Window(10000)
        window.setProperty(__addonid__ + ".backup.running", "false")

        # Perform setup operations
        setup_complete = perform_setup_function(runtime_config, runtime_config_lock)
        log.info("Snapshot 6")
        if setup_complete:

            # Setup event logger
            log.info("Snapshot 7")
            el = EventLogger(auth_session=runtime_config['session_auth'])
            startup_success_data = {
                'application':
                    {
                        'app_id': __addonid__,
                        'app_name': __addonname__,
                        'app_version': __addonversion__
                    },
                'system_info': runtime_config['system_info']
            }
            log.info("Snapshot 8")
            worker_threads.append(ProcessNotificationsThread(runtime_config,
                                                             runtime_config_lock,
                                                             wakeup_flag,
                                                             notification_queue,
                                                             el))
            worker_threads[-1].start()
            # worker_threads.append(RepeatingTimerThread("BackupWatchedStatusThread",
            #                                            3600,
            #                                            automatic_backup_watchedstatus,
            #                                            runtime_config,
            #                                            runtime_config_lock,
            #                                            exit_flag,
            #                                            el))
            # worker_threads[-1].start()
            # Make the VideoLibraryUpdateThread the last one as it is the one
            # that is likely to block on exit due to long polling
            worker_threads.append(VideoLibraryUpdateThread(runtime_config,
                                                           runtime_config_lock,
                                                           wakeup_flag))
            worker_threads[-1].daemon = True
            worker_threads[-1].start()
            log.info("Snapshot 9")
            # Confirm startup successful
            log.info("Completed startup successfully")
            el.new('kodi.client.setup.complete', startup_success_data)

            try:
                while not kn.abortRequested():
                    # Sleep/wait for abort
                    if kn.waitForAbort(60):
                        # Abort was requested while waiting. We should exit
                        break
                    log.debug("service.watchedsync waited 60 secs for abort signal...")
            except KeyboardInterrupt:
                log.debug('Keyboard Interrupted')

        else:
            log.error("Failed to complete setup. Terminating service")

    except Exception as e:
        log.info("Snapshot 10")
        # sentry_sdk.capture_exception()
        # Failed during startup process - Inform user
        msg = "{}".format(getString(32015))
        displayOKDialog(msg)
        log.error("Unexpected error - please raise issue on "
                  "https://github.com/watchedsyncforkodi/service.watchedsync/issues")
        log.error(e)
        raise

    # Cleanly shutdown

    # Tell threads to exit
    exit_flag.set()

    for t in worker_threads:
        t.stop()

    # Update settings to mark offline
    setSettingAsString("addon_status", getString(32011))
    setSettingAsBool("connected_online", False)

    # Stop the EventLogger
    if el:
        el.stop()

    # Close down sentry
    # if sentry_sdk.Hub.current.client:
    #     sentry_sdk.Hub.current.client.close(timeout=1.0)

    # Delete KodiNotification (kodi.Monitor)
    del kn

    log.debug("Received abortRequested() - waiting for threads to exit")
    # Attempt to wait for threads to cleanly exit. If they don't kodi will
    # forcibly kill the process anyway
    for t in worker_threads:
        log.info("Waiting for thread '{}' to exit".format(t.name))
        t.join(2.0)
        if t.is_alive():
            # Thread is still alive
            log.warning("Thread '{}' has not exited cleanly".format(t.name))

    log.info('Main service exiting')


if __name__ == '__main__':
    main()
