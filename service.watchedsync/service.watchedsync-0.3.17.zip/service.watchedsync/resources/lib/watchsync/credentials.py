#
#
# Copyright 2016-2025 CSS
#
# This software is unpublished work which is proprietary to CSS.
# Any distribution is strictly forbidden
#

import sys
import os
import uuid
import json
import requests

import xbmc
import xbmcvfs
import xbmcaddon

LIB_RESOURCES_PATH = xbmcvfs.translatePath(os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'lib'))
sys.path.append(LIB_RESOURCES_PATH)

""" Local module imports - need to be after LIB_RESOURCES_PATH """
from watchsync.logging import KodiLog
from watchsync.utils import getString, getSettingAsString, setSettingAsString, displayOKDialog
from watchsync.auth import AuthSession


__addon__ = xbmcaddon.Addon()
__addonname__ = __addon__.getAddonInfo('name')
__addonversion__ = __addon__.getAddonInfo('version')
__addonid__ = __addon__.getAddonInfo('id')
__addonpath__ = __addon__.getAddonInfo('path')
__addonprofile__ = xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__credentialsfile__ = xbmcvfs.validatePath(os.path.join(__addonprofile__, 'credentials.json'))

log = KodiLog(__file__, __name__)

""" Configuration Variables
"""
REGISTER_TIMEOUT = 20.0
REGISTER_MAX_BACKOFF = 433
HTTP_GET_TIMEOUT = 3.1
_request_timeout = 15
""" End of Configuration Variables
"""

_default_credentials = {
    "in_registration_mode": True,
    "device_registration_code": str(uuid.uuid4())
}


def _read_credentials_file() -> dict:
    """
        Read credentials file and return content

    :return credentials content:
    """
    try:
        with open(__credentialsfile__, 'rt', encoding="utf-8", newline='\n') as credentials_file:
            parsed_credentials_file = json.load(credentials_file)

    except FileNotFoundError:
        # On first use there will be no file so expect FileNotFoundError exception
        parsed_credentials_file = _default_credentials.copy()

        # Write to file
        _write_credentials_file(parsed_credentials_file)

    return parsed_credentials_file


def _write_credentials_file(credentials_input: dict) -> bool:
    """
        Write credentials file using supplied dict

    :return true if successful:
    """
    with open(__credentialsfile__, 'wt', encoding="utf-8", newline='\n') as credentials_file:
        json.dump(credentials_input, credentials_file, sort_keys=True)

    return True


def migrate_credentials_from_settings():
    """
        Migrate storage of credentials from settings.xml to the credentials file

    :return:
    """
    existing_client_id = getSettingAsString('auth_client_id')
    existing_client_secret = getSettingAsString('auth_client_secret')
    if existing_client_id and existing_client_secret:
        # Migrate credentials - should only need to do once
        parsed_credentials = _read_credentials_file()
        parsed_credentials['auth_client_id'] = existing_client_id
        parsed_credentials['auth_client_secret'] = existing_client_secret
        parsed_credentials['in_registration_mode'] = False
        _write_credentials_file(parsed_credentials)

        # Remove credentials from settings.xml
        setSettingAsString('auth_client_id', '')
        setSettingAsString('auth_client_secret', '')

        log.info("Successfully migrated credentials format")


def generate_registration_code(runtime_config, runtime_config_lock):
    """
        Generate registration code for this device and store in runtime config

    :param runtime_config:
    :param runtime_config_lock:
    :return registration code string:
    """
    # See if we already have stored a registration code
    parsed_credentials = _read_credentials_file()
    registration_code = parsed_credentials["device_registration_code"]

    # Make friendlier version of registration code to display to user
    friendly_registration_code = '-'.join((registration_code[0:4], registration_code[4:8])).upper()

    with runtime_config_lock:
        runtime_config['device_registration_code'] = registration_code
        runtime_config['friendly_registration_code'] = friendly_registration_code


def is_device_registered() -> bool:
    """
        Check whether this device has completed registration

    :return true/false:
    """
    parsed_credentials = _read_credentials_file()
    return parsed_credentials['in_registration_mode'] == False


def get_device_client_id() -> str:
    """
        Return client_id if available
    :return client_id:
    """
    parsed_credentials = _read_credentials_file()
    # auth_client_id may not be in the parsed_credentials so return empty string if missing
    return parsed_credentials.get('auth_client_id', '')


def register_device(runtime_config, runtime_config_lock):
    """
        Attempt to register this device

    :param runtime_config:
    :param runtime_config_lock:
    :return:
    """
    register_endpoint = None
    data_to_submit = {
        'application': {
            'app_id': __addonid__,
            'app_name': __addonname__,
            'app_version': __addonversion__,
            'app_credentials_path': __credentialsfile__
        }
    }

    # Generate registration code
    generate_registration_code(runtime_config, runtime_config_lock)

    with runtime_config_lock:
        register_endpoint = runtime_config['endpoints']['register_endpoint']
        data_to_submit['system_info'] = runtime_config['system_info']
        data_to_submit['registration_code'] = runtime_config['device_registration_code']
        data_to_submit['friendly_registration_code'] = runtime_config['friendly_registration_code']

    log.info("Snapshot 1")

    # Attempt registration
    custom_headers = {
        'user-agent': xbmc.getUserAgent(),
        'Content-Type': 'application/json'
    }
    log.info("Snapshot 2")
    r = requests.post(url=register_endpoint,
                      json=data_to_submit,
                      headers=custom_headers,
                      timeout=_request_timeout)
    log.info("Snapshot 2a")
    if 400 <= r.status_code < 500:
        # Failed registration process
        # Indicate in settings status that we are currently unregistered
        # 32008 - Unregistered
        setSettingAsString("addon_status", getString(32008))

        # Inform user on screen to register offline
        msg = "{} {}".format(getString(32014), data_to_submit['friendly_registration_code'])
        displayOKDialog(msg)

    log.info("Snapshot 2b")
    r.raise_for_status()
    log.info("Snapshot 2c")
    reg_output = r.json()
    log.info("Snapshot 2d")
    # output = {
    #     'auth_client_id': cd_xxxx,
    #     'auth_client_secret': xxxxxxx,
    #     'registration_status': 'successful'
    # }
    if reg_output['registration_status'] == 'successful':
        # Store information permanently
        parsed_credentials = _read_credentials_file()
        parsed_credentials['auth_client_id'] = reg_output['auth_client_id']
        parsed_credentials['auth_client_secret'] = reg_output['auth_client_secret']
        parsed_credentials['in_registration_mode'] = False
        _write_credentials_file(parsed_credentials)

        log.info("Successfully registered device")

        # Advise user registration was successful
        msg = "{}".format(getString(32019))
        displayOKDialog(msg)


def authorise_device(runtime_config, runtime_config_lock):
    """
        Authorise device with service

    :param runtime_config:
    :param runtime_config_lock:
    :return:
    """
    # Get credentials
    parsed_credentials = _read_credentials_file()
    auth_client_id = parsed_credentials.get('auth_client_id', None)
    auth_client_secret = parsed_credentials.get('auth_client_secret', None)

    # Call to AuthSession will raise exceptions if fails
    auth_session = AuthSession(scope='watchsync.client/event.write watchsync.client/task.read',
                               client_id=auth_client_id,
                               client_secret=auth_client_secret)

    # Set up authenticated session to be used by other modules
    with runtime_config_lock:
        runtime_config['session_auth'] = auth_session
