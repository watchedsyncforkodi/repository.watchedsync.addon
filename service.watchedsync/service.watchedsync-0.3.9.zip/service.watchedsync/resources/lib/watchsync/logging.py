#
#
# Copyright 2019-2021 CSS
#
# This software is unpublished work which is proprietary to CSS.
# Any distribution is strictly forbidden
#
#

import xbmc
import xbmcaddon

__addon__ = xbmcaddon.Addon()
__addonversion__ = __addon__.getAddonInfo('version')
__addonid__ = __addon__.getAddonInfo('id')
__addonpath__ = __addon__.getAddonInfo('path')


class KodiLog(object):
    def __init__(self, module_name, class_name=None):
        self.module_name = module_name
        self.class_name = class_name

    def debug(self, msg):
        self._log(msg, xbmc.LOGDEBUG)

    def info(self, msg):
        self._log(msg, xbmc.LOGINFO)

    def warning(self, msg):
        self._log(msg, xbmc.LOGWARNING)

    def error(self, msg):
        self._log(msg, xbmc.LOGERROR)

    def _log(self, msg, level):

        # if isinstance(msg, str):
        #     msg = msg.encode('utf-8')

        if level == xbmc.LOGDEBUG:
            xbmc.log("[{}][{}][{}] {}".format(__addonid__, self.module_name, self.class_name, msg), level)
        else:
            xbmc.log("[{}] {}".format(__addonid__, msg), level)
