#
#
# Copyright 2019-2021 CSS
#
# This software is unpublished work which is proprietary to CSS.
# Any distribution is strictly forbidden
#
#

import sys
import os
import threading
import queue
import json
import xbmc
import xbmcvfs
import xbmcaddon
from datetime import datetime

LIB_RESOURCES_PATH = xbmcvfs.translatePath(os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'lib'))
sys.path.append(LIB_RESOURCES_PATH)

""" Local module imports - need to be after LIB_RESOURCES_PATH """
from watchsync.logging import KodiLog
from watchsync.utils import BackgroundThread, get_movie_details, get_tvshow_details, get_episode_details, PriorityItem
# import sentry_sdk


__addon__ = xbmcaddon.Addon()
__addonname__ = __addon__.getAddonInfo('name')
__addonversion__ = __addon__.getAddonInfo('version')
__addonid__ = __addon__.getAddonInfo('id')
__addonpath__ = __addon__.getAddonInfo('path')
__addonprofile__ = xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))

# sentry_sdk.init(
#     "https://9872e16f507545fa9edcdcbf47632fe7@o425593.ingest.sentry.io/5510343",
#     environment="production",
#     release="{}@{}".format(__addonid__, __addonversion__)
# )

class KodiNotifications(xbmc.Monitor):

    def __init__(self, notification_queue):
        super(KodiNotifications, self).__init__()
        self.log = KodiLog(__file__, __name__)
        self.process_queue = notification_queue
        self.last_video_scan_duration = -1.0
        self.last_video_clean_duration = -1.0
        self.is_video_scanning = False
        self.last_video_scan_start_dt = None

    def onNotification(self, sender, method, data):

        if sender == "xbmc" and method == "VideoLibrary.OnScanStarted":
            self.is_video_scanning = True
            self.last_video_scan_start_dt = datetime.utcnow()

        elif sender == "xbmc" and method == "VideoLibrary.OnScanFinished":
            self.is_video_scanning = False
            if self.last_video_scan_start_dt:
                self.last_video_scan_duration = (datetime.utcnow() - self.last_video_scan_start_dt).total_seconds()
                self.last_video_scan_start_dt = None

        if sender == "xbmc" and method in ["System.OnWake", "GUI.OnScreensaverDeactivated",
                                           "GUI.OnScreensaverActivated", "VideoLibrary.OnScanFinished"]:
            # Trigger wakeup of the remote end
            msg = {
                "sender": sender,
                "method": method,
                "data": None
            }
            # Put on higher priority
            self.process_queue.put(PriorityItem(50, msg))

        elif sender == "xbmc" and method == "VideoLibrary.OnUpdate":
            # Parse data back into dict
            parsed_data = json.loads(data)
            # Ignore transaction updates
            if 'transaction' in parsed_data and parsed_data['transaction']:
                pass
            # Ignore newly added items
            elif 'added' in parsed_data and parsed_data['added']:
                pass
            # Bug in kodi means duplicates can be issued. Look for item attribute
            elif 'item' in parsed_data:
                # Process notification
                msg = {
                    "sender": sender,
                    "method": method,
                    "data": data
                }
                self.process_queue.put(PriorityItem(100, msg))


class ProcessNotificationsThread(BackgroundThread):

    def __init__(self, runtime_config, runtime_config_lock, wakeup_flag, notification_queue, event_logger):
        super(ProcessNotificationsThread, self).__init__(name="ProcessNotificationsThread")

        self.rt_config = runtime_config
        self.rt_lock = runtime_config_lock
        self.wakeup_flag = wakeup_flag
        self.log = KodiLog(__file__, __name__)
        self.process_queue = notification_queue
        self.el = event_logger

        with self.rt_lock:
            self.auth_session = runtime_config['session_auth']
            self.update_poll_interval = runtime_config['update_library_poll_interval']
            self.update_queue_url = runtime_config['update_library_queue_url']

    def stop(self):
        # call from parent to stop and exit thread
        # Send poison pill
        self.process_queue.put(PriorityItem(5, None))
        self.exit_flag.set()

    def run(self):
        # Called by calling start()
        self.log.info("Starting thread: {}".format(threading.current_thread().name))

        while not self.exit_flag.is_set():
            try:
                next_msg = self.process_queue.get(True, 3.0)

                self.log.debug("Received event from queue with pri {}: {}".format(next_msg.priority, next_msg.item))

                # PriorityQueue - filter out weighting - not used elsewhere
                next_msg = next_msg.item
                if next_msg is None:
                    # Poison pill
                    break

                # Process message
                if next_msg['sender'] == 'xbmc' and next_msg['method'] == 'VideoLibrary.OnUpdate':
                    event_type = 'kodi.client.notification.{}'.format(next_msg['method'])
                    event_msg = {
                        'notification': next_msg
                    }
                    # Parse data back into dict
                    parsed_data = json.loads(next_msg['data'])
                    event_msg['notification']['data'] = parsed_data
                    update_type = parsed_data['item']['type']

                    # Check it wasn't us that triggered the update
                    with self.rt_lock:
                        # runtime_config['ignore_updates_from'] = {
                        #     'movie': set(),
                        #     'episode': set()
                        # }
                        if parsed_data['item']['id'] in self.rt_config['ignore_updates_from'][update_type]:
                            # It was us
                            self.log.debug("Self generated - ignoring VideoLibrary.OnUpdate for {} id {}".format(update_type,
                                                                                                                 parsed_data['item']['id']))
                            self.rt_config['ignore_updates_from'][update_type].remove(parsed_data['item']['id'])
                            continue

                    if update_type == 'movie':
                        event_msg['moviedetails'] = get_movie_details(parsed_data['item']['id'])
                    elif update_type == 'episode':
                        event_msg['episodedetails'] = get_episode_details(parsed_data['item']['id'])
                        event_msg['tvshowdetails'] = get_tvshow_details(event_msg['episodedetails']['tvshowid'])
                    else:
                        # Silently ignore other update types at this time
                        continue

                    self.el.new(event_type, event_msg)

                if next_msg['sender'] == 'xbmc' and next_msg['method'] in ["System.OnWake", "GUI.OnScreensaverDeactivated",
                                                                           "VideoLibrary.OnScanFinished"]:
                    self.log.debug("Waking up VideoLibraryUpdateThread")
                    self.wakeup_flag.set()

                if next_msg['sender'] == 'xbmc' and next_msg['method'] in ["GUI.OnScreensaverActivated",
                                                                           "GUI.OnScreensaverDeactivated"]:
                    event_type = 'kodi.client.notification.{}'.format(next_msg['method'])
                    event_msg = {
                        'notification': next_msg
                    }
                    self.el.new(event_type, event_msg)

                # Simulate process message
                xbmc.sleep(750)

                # Finished processing msg

            except queue.Empty:
                continue

            except Exception as e:
                # sentry_sdk.capture_exception()
                self.log.error("Unexpected error - please raise issue on "
                               "https://github.com/watchedsyncforkodi/service.watchedsync/issues")
                self.log.error(e)
                raise

        self.log.info("Exiting thread: {}".format(threading.current_thread().name))


if __name__ == '__main__':
    pass
