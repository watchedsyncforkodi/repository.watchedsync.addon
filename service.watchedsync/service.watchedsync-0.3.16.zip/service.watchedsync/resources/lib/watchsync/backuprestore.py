#
#
# Copyright 2019-2022 CSS
#
# This software is unpublished work which is proprietary to CSS.
# Any distribution is strictly forbidden
#
#

import sys
import os
import threading
import json
import requests
import tempfile
import hashlib
import pytz
from datetime import datetime
from time import sleep, monotonic
from functools import lru_cache
import xbmc
import xbmcvfs
import xbmcaddon

LIB_RESOURCES_PATH = xbmcvfs.translatePath(os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'lib'))
sys.path.append(LIB_RESOURCES_PATH)

""" Local module imports - need to be after LIB_RESOURCES_PATH """
from watchsync.logging import KodiLog
from watchsync.auth import AuthBoto3Direct, AuthSessionError
from watchsync.utils import BackgroundThread, getSettingAsString, indicate_connection_offline, indicate_connection_online
from watchsync.utils import scan_video_library, update_content_watch_status, setSettingAsBool
from watchsync.utils import find_content_with_filepath, setSettingAsString, getString
from watchsync.utils import get_tvshowid_from_uniqueid, get_movieid_from_uniqueid, issue_kodi_jsonrpc_command
from watchsync.utils import get_results_from_kodi_jsonrpc, get_tvshow_details, getSettingAsBool
# import sentry_sdk
import boto3
from botocore.exceptions import ClientError, ConnectionError, HTTPClientError

__addon__ = xbmcaddon.Addon()
__addonname__ = __addon__.getAddonInfo('name')
__addonversion__ = __addon__.getAddonInfo('version')
__addonid__ = __addon__.getAddonInfo('id')
__addonpath__ = __addon__.getAddonInfo('path')
__addonprofile__ = xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__backupchecksum__ = xbmcvfs.translatePath(os.path.join(xbmcaddon.Addon().getAddonInfo('profile'), 'backup_checksum.json'))

# sentry_sdk.init(
#     "https://9872e16f507545fa9edcdcbf47632fe7@o425593.ingest.sentry.io/5510343",
#     environment="production",
#     release="{}@{}".format(__addonid__, __addonversion__)
# )


""" Configuration Variables
"""
REGISTER_TIMEOUT = 20.0
REGISTER_MAX_BACKOFF = 433
HTTP_GET_TIMEOUT = 3.1
""" End of Configuration Variables
"""


def get_all_watched_status():
    """
        Return iterator of all watch statuses for both TV shows and fillms

    :return: Iterator of watch status
    """
    # content type logic
    content_types = [
        {
            "method": "VideoLibrary.GetEpisodes",
            "result_name": "episodes",
            "properties": ["tvshowid", "title", "file", "lastplayed", "resume", "playcount", "season", "episode"],
        },
        {
            "method": "VideoLibrary.GetMovies",
            "result_name": "movies",
            "properties": ["title", "file", "lastplayed", "resume", "playcount", "uniqueid"],
        }
    ]

    @lru_cache(maxsize=1024)
    def _get_cached_tvshow_details(tvshowid):
        return get_tvshow_details(tvshowid)

    for c in content_types:
        for r in get_results_from_kodi_jsonrpc(c['method'], c['result_name'], c['properties']):
            # Only backup if watched/resume points exist
            if r["playcount"] == 0 and r["resume"]["position"] == 0.0:
                # No activity detected on this result - ignore
                continue

            # Merge data from tvshow details if episodes
            if c['result_name'] == "episodes":
                r.update(_get_cached_tvshow_details(r["tvshowid"]))

            yield r


def backup_watchedstatus(runtime_config, runtime_config_lock, lockfile, exit_flag, el):
    """
        Backup all resume points and watched status from kodi device

    :param runtime_config: Runtime configuration
    :param runtime_config_lock: Runtime config access lock
    :param lockfile: Fastener lock file for locking between backup and restore
    :param exit_flag: Flag to indicate exit (due to shutdown)
    :param el: Event Logger
    :return: status message of busy, error, or completed_ok
    """
    log = KodiLog(__file__, __name__)
    backup_hash = hashlib.sha3_256()
    completed_data = {
        "metrics": {},
        "checksum_matches": False,
        "resumepoint_count": 0,
        "last_checksum_data": None,
        "backup_checksum_sha3_256": None,
        'application': {
            'app_id': __addonid__,
            'app_name': __addonname__,
            'app_version': __addonversion__
        }
    }

    # Check whether already running
    if lockfile.acquired:
        log.warning("Can't run backup process as one is already running")
        return "busy"

    # Get exclusive access running backup/restore
    with lockfile:
        log.info("Starting backup of watched status")
        log.debug("Acquired exclusive lock to run backup")

        with tempfile.NamedTemporaryFile('wt+', encoding="utf-8", newline='\n') as backup_file:

            # Phase 1 - retrieve watch status
            start = monotonic()
            for count, r in enumerate(get_all_watched_status()):
                r_converted = json.dumps(r, sort_keys=True)
                backup_file.write(r_converted)
                backup_file.write('\n')
                backup_hash.update(r_converted.encode('utf-8'))

            elapsed = monotonic() - start
            completed_data['resumepoint_count'] = count + 1
            completed_data['backup_checksum_sha3_256'] = backup_hash.hexdigest()
            completed_data['metrics']['phase_1'] = "{:.1f}".format(elapsed * 1000)
            log.debug("Phase 1 - retrieved watch status (took {:.1f}ms)".format(elapsed * 1000))

            # Check whether checksum matches
            last_checksum = {
                "checksum_sha3_256": "",
                "from_checksum_file": False
            }
            try:
                # On first use there will be no file so expect FileNotFoundError exception
                with open(__backupchecksum__, 'rt', encoding="utf-8", newline='\n') as checksum_file:
                    last_checksum = json.load(checksum_file)
                    completed_data['last_checksum_data'] = last_checksum
            except:
                pass

            if backup_hash.hexdigest() == last_checksum['checksum_sha3_256']:
                # No changes since last backup
                log.debug("Last checksum data: {}".format(last_checksum))
                log.debug("Backup checksum: {}".format(backup_hash.hexdigest()))
                completed_data['checksum_matches'] = True
                el.new('kodi.client.backup.complete', completed_data)
                log.info("Completed backup of watched status. No changes detected since last backup")
                return "completed_ok"

            # Phase 2 - changes detected - need to upload to cloud
            # Reset file position
            backup_file.seek(0)
            completed_data['checksum_matches'] = False
            start = monotonic()
            for line in backup_file:
                parsed_line = json.loads(line)
                # Send to cloud
                el.new('kodi.client.backup.resumepoint', parsed_line)

            # Monitor backlog to see when all resumepoints have been uploaded
            while not exit_flag.is_set() and el.backlog_size() > 1:
                sleep(0.25)

            # Quit if exit flag is triggered
            if exit_flag.is_set():
                return "error"

            elapsed = monotonic() - start
            completed_data['metrics']['phase_2'] = "{:.1f}".format(elapsed * 1000)
            log.debug("Phase 2 - upload watch status (took {:.1f}ms)".format(elapsed * 1000))

            # Save checksum details
            this_checksum = {
                "checksum_sha3_256": backup_hash.hexdigest(),
                "from_checksum_file": True,
                "last_updated_utc_datetime": datetime.now(pytz.utc).strftime('%Y-%m-%dT%H:%M:%S%z')
            }
            with open(__backupchecksum__, 'wt', encoding="utf-8", newline='\n') as checksum_file:
                json.dump(this_checksum, checksum_file, sort_keys=True)
                log.debug("Written new backup checksum data: {}".format(this_checksum))

            # TODO: Update settings status

            el.new('kodi.client.backup.complete', completed_data)
            log.info("Completed backup of watched status")
            return "completed_ok"


def automatic_backup_watchedstatus(runtime_config, runtime_config_lock, lockfile, exit_flag, el):
    """
        Check whether automatic backup is enabled and then backup all resume points and watched status from kodi device

    :param runtime_config: Runtime configuration
    :param runtime_config_lock: Runtime config access lock
    :param lockfile: Fastener lock file for locking between backup and restore
    :param exit_flag: Flag to indicate exit (due to shutdown)
    :param el: Event Logger
    :return: status message of busy, error, or completed_ok
    """
    log = KodiLog(__file__, __name__)
    log.debug("Entering automatic_backup_watchedstatus with enabled setting set to: {}".format(getSettingAsBool('automatic_backup_enabled')))
    if getSettingAsBool('automatic_backup_enabled'):
        return backup_watchedstatus(runtime_config, runtime_config_lock, lockfile, exit_flag, el)

    return None
